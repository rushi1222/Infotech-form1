
import './App.css';
import One from './components/One';

function App() {

  return (
    <div className="App">
      <One></One>
    </div>
  );
}

export default App;
